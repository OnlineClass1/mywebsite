import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  originalName: text("original_name").notNull(),
  fileType: text("file_type").notNull(),
  fileSize: integer("file_size").notNull(),
  content: text("content").notNull(),
  summary: text("summary"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").references(() => documents.id),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertDocumentSchema = createInsertSchema(documents).pick({
  filename: true,
  originalName: true,
  fileType: true,
  fileSize: true,
  content: true,
});

export const insertConversationSchema = createInsertSchema(conversations).pick({
  documentId: true,
  question: true,
  answer: true,
});

export const questionSchema = z.object({
  documentId: z.number(),
  question: z.string().min(1),
});

export const humanizeSchema = z.object({
  text: z.string().min(1),
});

export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;
export type Question = z.infer<typeof questionSchema>;
export type HumanizeRequest = z.infer<typeof humanizeSchema>;
