# AI Document Genius

## Overview

AI Document Genius is a full-stack web application that allows users to upload, process, and interact with documents using AI-powered features. The application provides document summarization, question-answering capabilities, and text humanization services powered by Google's Gemini AI.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modern full-stack architecture with clear separation between client and server components:

- **Frontend**: React-based SPA with TypeScript, using Vite for development and building
- **Backend**: Express.js REST API server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM for data management
- **AI Integration**: Google Gemini AI for document processing and natural language tasks
- **File Processing**: Server-side document parsing for multiple file formats
- **UI Framework**: Tailwind CSS with shadcn/ui component library

## Key Components

### Frontend Architecture
- **React Router**: Using Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **UI Components**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom theme configuration
- **Theme Support**: Light/dark mode with persistent user preferences

### Backend Architecture
- **Express Server**: RESTful API with TypeScript
- **File Upload**: Multer middleware for handling multipart/form-data
- **Document Processing**: Custom file processor supporting PDF, DOCX, PPT, PPTX, and TXT files
- **AI Services**: Gemini service wrapper for AI-powered features
- **Storage Layer**: Abstracted storage interface with in-memory implementation

### Database Schema
- **Documents Table**: Stores file metadata, content, and AI-generated summaries
- **Conversations Table**: Stores Q&A interactions linked to specific documents
- **Relationships**: Foreign key relationship between conversations and documents

## Data Flow

1. **Document Upload**: Client uploads file → Server processes and extracts text → Stores in database
2. **AI Processing**: Document content sent to Gemini → Summary generated → Stored with document
3. **Question Answering**: User question + document content sent to Gemini → AI response returned and stored
4. **Text Humanization**: User text sent to Gemini for humanization → Processed text returned

## External Dependencies

### AI Services
- **Google Gemini AI**: Primary AI service for document summarization, question answering, and text humanization
- **Model**: Uses "gemini-2.5-flash" for optimal performance and cost balance

### Database
- **Neon Database**: Serverless PostgreSQL database
- **Drizzle ORM**: Type-safe database operations with schema migrations

### File Processing Libraries
- **pdf-parse**: PDF text extraction
- **mammoth**: DOCX document processing
- **Custom PPT handler**: Basic PowerPoint file processing

### UI and Styling
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library
- **react-dropzone**: File upload interface

## Deployment Strategy

### Development
- **Vite Dev Server**: Hot module replacement for frontend development
- **Express Server**: Development server with request logging and error handling
- **Environment Variables**: DATABASE_URL and GEMINI_API_KEY required

### Production Build
- **Frontend**: Vite builds static assets to `dist/public`
- **Backend**: esbuild bundles server code to `dist/index.js`
- **Database**: Drizzle migrations applied via `db:push` command

### Storage Considerations
- Currently uses in-memory storage for documents (suitable for development)
- Production deployment would require persistent database storage
- File uploads are processed in-memory (50MB limit)

The application is designed to be easily deployable on platforms like Replit, with proper environment variable configuration for database and AI service credentials.

## Recent Changes

### July 18, 2025
- ✅ **Complete Application Built**: Full-stack AI Document Genius application now running
- ✅ **File Upload Fixed**: Resolved FormData handling issue in client-side API requests  
- ✅ **AI Integration**: Google Gemini API successfully integrated for summarization, Q&A, and text humanization
- ✅ **Multi-format Support**: PDF, DOCX, PPT, PPTX, and TXT file processing implemented
- ✅ **UI/UX Complete**: Modern gradient design with dark/light theme toggle, responsive layout
- ✅ **Download Features**: Users can download summaries, Q&A sessions, and humanized text as .txt files
- ✅ **Security**: API keys properly secured on backend, never exposed to frontend