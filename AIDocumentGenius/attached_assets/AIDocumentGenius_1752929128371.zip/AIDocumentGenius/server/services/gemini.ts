import { GoogleGenAI } from "@google/genai";

// DON'T DELETE THIS COMMENT
// Follow these instructions when using this blueprint:
// - Note that the newest Gemini model series is "gemini-2.5-flash" or gemini-2.5-pro"
//   - do not change this unless explicitly requested by the user

// This API key is from Gemini Developer API Key, not vertex AI API Key
const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || "" 
});

export class GeminiService {
  async generateSummary(content: string): Promise<string> {
    try {
      const prompt = `Please provide a comprehensive summary of the following document content. 
      Format your response with:
      - Clear headings and subheadings
      - Bullet points for key information
      - Numbered lists for sequential information
      - Proper structure and organization
      
      Document content:
      ${content}
      
      Please ensure the summary is well-structured, informative, and maintains the key points from the original content.`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
      });

      return response.text || "Unable to generate summary";
    } catch (error) {
      console.error('Error generating summary:', error);
      throw new Error(`Failed to generate summary: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async answerQuestion(documentContent: string, question: string): Promise<string> {
    try {
      const prompt = `Based on the following document content, please answer the question as accurately and comprehensively as possible.
      
      Document content:
      ${documentContent}
      
      Question: ${question}
      
      Please provide a detailed answer based solely on the information available in the document. If the information is not available in the document, please state that clearly. Include relevant context and be specific about which parts of the document support your answer.`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-pro",
        contents: prompt,
      });

      return response.text || "Unable to answer the question";
    } catch (error) {
      console.error('Error answering question:', error);
      throw new Error(`Failed to answer question: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async humanizeText(text: string): Promise<string> {
    try {
      const prompt = `Please rewrite the following text to make it more human-like, engaging, and natural while preserving all the original meaning and key information. 
      
      Guidelines for humanization:
      - Use conversational tone where appropriate
      - Vary sentence structure and length
      - Replace overly formal or robotic language with more natural expressions
      - Maintain professionalism while making it more readable
      - Keep all factual information intact
      - Make it flow better and be more engaging to read
      
      Original text:
      ${text}
      
      Please provide the humanized version that sounds more natural and engaging while keeping the same core message and information.`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
      });

      return response.text || "Unable to humanize text";
    } catch (error) {
      console.error('Error humanizing text:', error);
      throw new Error(`Failed to humanize text: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async extractKeyPoints(content: string): Promise<string[]> {
    try {
      const systemPrompt = `You are an expert at analyzing documents and extracting key points. 
      Analyze the content and extract the most important points as a JSON array of strings.
      Focus on the main ideas, conclusions, and actionable insights.
      Respond with JSON in this format: 
      {"keyPoints": ["point1", "point2", "point3"]}`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-pro",
        config: {
          systemInstruction: systemPrompt,
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              keyPoints: {
                type: "array",
                items: { type: "string" }
              }
            },
            required: ["keyPoints"]
          }
        },
        contents: content,
      });

      const rawJson = response.text;
      if (rawJson) {
        const data = JSON.parse(rawJson);
        return data.keyPoints || [];
      }
      return [];
    } catch (error) {
      console.error('Error extracting key points:', error);
      throw new Error(`Failed to extract key points: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
}

export const geminiService = new GeminiService();
