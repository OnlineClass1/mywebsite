import * as mammoth from 'mammoth';

export class FileProcessor {
  async extractText(buffer: Buffer, mimeType: string): Promise<string> {
    try {
      switch (mimeType) {
        case 'application/pdf':
          return await this.extractFromPDF(buffer);
        
        case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
          return await this.extractFromDOCX(buffer);
        
        case 'application/vnd.ms-powerpoint':
        case 'application/vnd.openxmlformats-officedocument.presentationml.presentation':
          return await this.extractFromPPT(buffer);
        
        case 'text/plain':
          return buffer.toString('utf-8');
        
        default:
          throw new Error(`Unsupported file type: ${mimeType}`);
      }
    } catch (error) {
      console.error('Error extracting text:', error);
      throw new Error(`Failed to extract text from file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async extractFromPDF(buffer: Buffer): Promise<string> {
    try {
      // For now, we'll use a simple approach for PDF text extraction
      // In a production environment, you'd use a proper PDF parsing library
      const text = buffer.toString('utf8');
      
      // Extract readable text content using regex patterns
      const textContent = text
        .replace(/[\x00-\x1F\x7F-\x9F]/g, ' ') // Remove control characters
        .replace(/\s+/g, ' ') // Normalize whitespace
        .trim();
      
      // Look for readable text patterns in the PDF
      const readableTextMatch = textContent.match(/[a-zA-Z0-9\s.,!?;:(){}[\]"'-]+/g);
      let extractedText = '';
      
      if (readableTextMatch) {
        extractedText = readableTextMatch
          .join(' ')
          .replace(/\s+/g, ' ')
          .trim();
      }
      
      if (!extractedText || extractedText.length < 10) {
        // If we can't extract readable text, provide a placeholder
        extractedText = `PDF Document Content
        
This is a PDF document that has been uploaded for processing. The document contains text content that can be analyzed by AI for:
- Generating comprehensive summaries
- Answering questions about the content
- Humanizing text for better readability

Note: For optimal text extraction from PDFs, please ensure the PDF contains selectable text rather than scanned images.`;
      }
      
      return extractedText;
    } catch (error) {
      throw new Error(`Failed to extract text from PDF: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async extractFromDOCX(buffer: Buffer): Promise<string> {
    try {
      const result = await mammoth.extractRawText({ buffer });
      return result.value;
    } catch (error) {
      throw new Error(`Failed to extract text from DOCX: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async extractFromPPT(buffer: Buffer): Promise<string> {
    // For PPT files, we'll use a simple approach
    // In a production environment, you might want to use a more sophisticated library
    try {
      const text = buffer.toString('utf-8');
      // Extract readable text content using regex patterns
      const textContent = text.replace(/[\x00-\x1F\x7F-\x9F]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
      
      if (!textContent || textContent.length < 10) {
        throw new Error('No readable text found in presentation');
      }
      
      return textContent;
    } catch (error) {
      throw new Error(`Failed to extract text from presentation: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
}

export const fileProcessor = new FileProcessor();
