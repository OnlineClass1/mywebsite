import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { storage } from "./storage";
import { geminiService } from "./services/gemini";
import { fileProcessor } from "./services/fileProcessor";
import { 
  insertDocumentSchema, 
  insertConversationSchema, 
  questionSchema, 
  humanizeSchema 
} from "@shared/schema";
import { z } from "zod";

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB limit
  fileFilter: (req: any, file: any, cb: any) => {
    console.log('File upload attempt:', {
      originalname: file.originalname,
      mimetype: file.mimetype,
      size: file.size
    });
    
    const allowedTypes = [
      'application/pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-powerpoint',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'text/plain'
    ];
    
    const allowedExtensions = ['.pdf', '.docx', '.ppt', '.pptx', '.txt'];
    const fileExtension = file.originalname.toLowerCase().split('.').pop();
    
    if (allowedTypes.includes(file.mimetype) || allowedExtensions.includes(`.${fileExtension}`)) {
      cb(null, true);
    } else {
      console.log('File rejected:', file.mimetype, fileExtension);
      cb(new Error(`Invalid file type. Only PDF, DOCX, PPT, PPTX, and TXT files are allowed. Received: ${file.mimetype}`));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Upload and process document
  app.post("/api/documents", upload.single('file'), async (req: Request & { file?: any }, res) => {
    try {
      console.log('Upload request received:', {
        hasFile: !!req.file,
        body: req.body,
        headers: req.headers['content-type']
      });
      
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const { originalname, mimetype, size, buffer } = req.file;
      
      console.log('Processing file:', {
        originalname,
        mimetype,
        size,
        bufferLength: buffer.length
      });
      
      // Extract text content from file
      const content = await fileProcessor.extractText(buffer, mimetype);
      
      if (!content.trim()) {
        return res.status(400).json({ message: "Could not extract text from file" });
      }

      // Create document record
      const documentData = {
        filename: `${Date.now()}_${originalname}`,
        originalName: originalname,
        fileType: mimetype,
        fileSize: size,
        content: content
      };

      const validatedData = insertDocumentSchema.parse(documentData);
      const document = await storage.createDocument(validatedData);

      // Generate summary using AI
      try {
        const summary = await geminiService.generateSummary(content);
        await storage.updateDocumentSummary(document.id, summary);
        document.summary = summary;
      } catch (error) {
        console.error('Error generating summary:', error);
        // Document is still created even if summary fails
      }

      res.json(document);
    } catch (error) {
      console.error('Error processing document:', error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Error processing document" 
      });
    }
  });

  // Get all documents
  app.get("/api/documents", async (req, res) => {
    try {
      const documents = await storage.getAllDocuments();
      res.json(documents);
    } catch (error) {
      console.error('Error fetching documents:', error);
      res.status(500).json({ message: "Error fetching documents" });
    }
  });

  // Get specific document
  app.get("/api/documents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const document = await storage.getDocument(id);
      
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }

      res.json(document);
    } catch (error) {
      console.error('Error fetching document:', error);
      res.status(500).json({ message: "Error fetching document" });
    }
  });

  // Ask question about document
  app.post("/api/documents/:id/questions", async (req, res) => {
    try {
      const documentId = parseInt(req.params.id);
      const { question } = questionSchema.parse({ ...req.body, documentId });

      const document = await storage.getDocument(documentId);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }

      // Generate answer using AI
      const answer = await geminiService.answerQuestion(document.content, question);
      
      // Save conversation
      const conversationData = {
        documentId,
        question,
        answer
      };

      const conversation = await storage.createConversation(conversationData);
      res.json(conversation);
    } catch (error) {
      console.error('Error answering question:', error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Error answering question" 
      });
    }
  });

  // Get conversations for document
  app.get("/api/documents/:id/conversations", async (req, res) => {
    try {
      const documentId = parseInt(req.params.id);
      const conversations = await storage.getConversationsByDocument(documentId);
      res.json(conversations);
    } catch (error) {
      console.error('Error fetching conversations:', error);
      res.status(500).json({ message: "Error fetching conversations" });
    }
  });

  // Humanize text
  app.post("/api/humanize", async (req, res) => {
    try {
      const { text } = humanizeSchema.parse(req.body);
      const humanizedText = await geminiService.humanizeText(text);
      res.json({ humanizedText });
    } catch (error) {
      console.error('Error humanizing text:', error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Error humanizing text" 
      });
    }
  });

  // Download text content
  app.get("/api/download/:type/:id", async (req, res) => {
    try {
      const { type, id } = req.params;
      
      if (type === "summary") {
        const document = await storage.getDocument(parseInt(id));
        if (!document || !document.summary) {
          return res.status(404).json({ message: "Summary not found" });
        }
        
        res.setHeader('Content-Type', 'text/plain');
        res.setHeader('Content-Disposition', `attachment; filename="${document.originalName}_summary.txt"`);
        res.send(document.summary);
      } else if (type === "conversation") {
        const conversation = await storage.getConversationsByDocument(parseInt(id));
        if (!conversation.length) {
          return res.status(404).json({ message: "Conversations not found" });
        }
        
        const conversationText = conversation.map(c => 
          `Q: ${c.question}\nA: ${c.answer}\n\n`
        ).join('');
        
        res.setHeader('Content-Type', 'text/plain');
        res.setHeader('Content-Disposition', `attachment; filename="conversations_${id}.txt"`);
        res.send(conversationText);
      } else {
        res.status(400).json({ message: "Invalid download type" });
      }
    } catch (error) {
      console.error('Error downloading content:', error);
      res.status(500).json({ message: "Error downloading content" });
    }
  });

  // Delete document
  app.delete("/api/documents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteDocument(id);
      res.json({ message: "Document deleted successfully" });
    } catch (error) {
      console.error('Error deleting document:', error);
      res.status(500).json({ message: "Error deleting document" });
    }
  });

  // Download project archive
  app.get("/api/download-project", async (req, res) => {
    try {
      const path = require('path');
      const fs = require('fs');
      const archivePath = path.join(process.cwd(), 'ai-document-genius.tar.gz');
      
      if (!fs.existsSync(archivePath)) {
        return res.status(404).json({ message: "Project archive not found" });
      }
      
      res.setHeader('Content-Type', 'application/gzip');
      res.setHeader('Content-Disposition', 'attachment; filename="ai-document-genius.tar.gz"');
      
      const fileStream = fs.createReadStream(archivePath);
      fileStream.pipe(res);
    } catch (error) {
      console.error('Error downloading project:', error);
      res.status(500).json({ message: "Error downloading project" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
