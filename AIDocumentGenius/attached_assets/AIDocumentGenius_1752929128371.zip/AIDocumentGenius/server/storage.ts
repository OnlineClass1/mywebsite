import { 
  documents, 
  conversations, 
  type Document, 
  type InsertDocument, 
  type Conversation, 
  type InsertConversation 
} from "@shared/schema";

export interface IStorage {
  // Document operations
  createDocument(document: InsertDocument): Promise<Document>;
  getDocument(id: number): Promise<Document | undefined>;
  getAllDocuments(): Promise<Document[]>;
  updateDocumentSummary(id: number, summary: string): Promise<Document | undefined>;
  deleteDocument(id: number): Promise<void>;

  // Conversation operations
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  getConversationsByDocument(documentId: number): Promise<Conversation[]>;
  deleteConversationsByDocument(documentId: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private documents: Map<number, Document>;
  private conversations: Map<number, Conversation>;
  private currentDocumentId: number;
  private currentConversationId: number;

  constructor() {
    this.documents = new Map();
    this.conversations = new Map();
    this.currentDocumentId = 1;
    this.currentConversationId = 1;
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = this.currentDocumentId++;
    const document: Document = {
      ...insertDocument,
      id,
      summary: null,
      createdAt: new Date(),
    };
    this.documents.set(id, document);
    return document;
  }

  async getDocument(id: number): Promise<Document | undefined> {
    return this.documents.get(id);
  }

  async getAllDocuments(): Promise<Document[]> {
    return Array.from(this.documents.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async updateDocumentSummary(id: number, summary: string): Promise<Document | undefined> {
    const document = this.documents.get(id);
    if (document) {
      document.summary = summary;
      this.documents.set(id, document);
      return document;
    }
    return undefined;
  }

  async deleteDocument(id: number): Promise<void> {
    this.documents.delete(id);
    await this.deleteConversationsByDocument(id);
  }

  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const id = this.currentConversationId++;
    const conversation: Conversation = {
      id,
      documentId: insertConversation.documentId || null,
      question: insertConversation.question,
      answer: insertConversation.answer,
      createdAt: new Date(),
    };
    this.conversations.set(id, conversation);
    return conversation;
  }

  async getConversationsByDocument(documentId: number): Promise<Conversation[]> {
    return Array.from(this.conversations.values())
      .filter(conv => conv.documentId === documentId)
      .sort((a, b) => new Date(a.createdAt!).getTime() - new Date(b.createdAt!).getTime());
  }

  async deleteConversationsByDocument(documentId: number): Promise<void> {
    const toDelete: number[] = [];
    this.conversations.forEach((conversation, id) => {
      if (conversation.documentId === documentId) {
        toDelete.push(id);
      }
    });
    toDelete.forEach(id => this.conversations.delete(id));
  }
}

export const storage = new MemStorage();
