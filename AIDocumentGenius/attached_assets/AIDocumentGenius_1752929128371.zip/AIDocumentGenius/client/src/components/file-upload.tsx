import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { CloudUpload, FileText, Trash2, Check } from 'lucide-react';
import { cn } from '@/lib/utils';

interface FileUploadProps {
  onFileUploaded?: (documentId: number) => void;
}

export function FileUpload({ onFileUploaded }: FileUploadProps) {
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadedFiles, setUploadedFiles] = useState<Array<{ id: number; name: string; size: string }>>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('file', file);
      
      const response = await apiRequest('POST', '/api/documents', formData);
      return response.json();
    },
    onSuccess: (data) => {
      setUploadedFiles(prev => [...prev, {
        id: data.id,
        name: data.originalName,
        size: formatFileSize(data.fileSize)
      }]);
      queryClient.invalidateQueries({ queryKey: ['/api/documents'] });
      toast({
        title: "Success!",
        description: "Document uploaded and processed successfully.",
      });
      onFileUploaded?.(data.id);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to upload document",
        variant: "destructive",
      });
    }
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    acceptedFiles.forEach(file => {
      // Simulate upload progress
      setUploadProgress(0);
      const interval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(interval);
            return prev;
          }
          return prev + Math.random() * 20;
        });
      }, 100);

      uploadMutation.mutate(file, {
        onSettled: () => {
          clearInterval(interval);
          setUploadProgress(100);
          setTimeout(() => setUploadProgress(0), 1000);
        }
      });
    });
  }, [uploadMutation]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'application/vnd.ms-powerpoint': ['.ppt'],
      'application/vnd.openxmlformats-officedocument.presentationml.presentation': ['.pptx'],
      'text/plain': ['.txt']
    },
    multiple: true,
    maxSize: 50 * 1024 * 1024, // 50MB
  });

  const removeFile = (fileId: number) => {
    setUploadedFiles(prev => prev.filter(f => f.id !== fileId));
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
      <CardContent className="p-6">
        <div className="text-center mb-6">
          <h2 className="text-3xl font-bold text-foreground mb-2">
            Upload Your Document
          </h2>
          <p className="text-muted-foreground">
            Support for PDF, PPT, DOCX, and plain text files
          </p>
        </div>

        <div
          {...getRootProps()}
          className={cn(
            "border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer",
            isDragActive
              ? "border-primary bg-primary/10"
              : "border-border hover:border-primary/50",
            uploadMutation.isPending && "pointer-events-none opacity-50"
          )}
        >
          <input {...getInputProps()} />
          <div className="space-y-4">
            <div className="text-6xl text-muted-foreground">
              <CloudUpload className="mx-auto w-16 h-16" />
            </div>
            <div>
              <h3 className="text-xl font-semibold text-foreground mb-2">
                {isDragActive ? "Drop files here" : "Drag & drop your files here"}
              </h3>
              <p className="text-muted-foreground mb-4">
                or click to browse
              </p>
              <Button 
                className="bg-gradient-to-r from-primary to-secondary hover:from-secondary hover:to-primary shadow-lg hover:shadow-xl transition-all"
                disabled={uploadMutation.isPending}
              >
                <FileText className="mr-2 h-4 w-4" />
                Choose Files
              </Button>
            </div>
            <div className="text-sm text-muted-foreground">
              Supported formats: PDF, PPT, DOCX, TXT
            </div>
          </div>
        </div>

        {uploadProgress > 0 && (
          <div className="mt-6">
            <Progress value={uploadProgress} className="h-2" />
            <div className="flex justify-between text-sm text-muted-foreground mt-2">
              <span>Uploading...</span>
              <span>{Math.round(uploadProgress)}%</span>
            </div>
          </div>
        )}

        {uploadedFiles.length > 0 && (
          <div className="mt-6 space-y-3">
            <h3 className="text-lg font-semibold text-foreground">Uploaded Files</h3>
            <div className="space-y-2">
              {uploadedFiles.map((file) => (
                <div
                  key={file.id}
                  className="flex items-center justify-between p-4 bg-muted/50 rounded-lg border border-border/50"
                >
                  <div className="flex items-center space-x-3">
                    <div className="bg-gradient-to-r from-primary to-secondary p-2 rounded-lg">
                      <FileText className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">{file.name}</h4>
                      <p className="text-sm text-muted-foreground">{file.size}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="bg-gradient-to-r from-green-500 to-emerald-500 text-white px-3 py-1 rounded-full text-sm font-medium flex items-center">
                      <Check className="w-3 h-3 mr-1" />
                      Ready
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeFile(file.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
