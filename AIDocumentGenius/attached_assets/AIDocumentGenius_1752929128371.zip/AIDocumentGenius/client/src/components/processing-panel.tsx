import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { 
  List, 
  MessageCircle, 
  UserPen, 
  Eye, 
  Download, 
  Send, 
  Sparkles, 
  Bot,
  User,
  MapPin
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface ProcessingPanelProps {
  documentId: number;
}

export function ProcessingPanel({ documentId }: ProcessingPanelProps) {
  const [question, setQuestion] = useState('');
  const [textToHumanize, setTextToHumanize] = useState('');
  const [humanizedText, setHumanizedText] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: document } = useQuery({
    queryKey: ['/api/documents', documentId],
    enabled: !!documentId,
  });

  const { data: conversations = [] } = useQuery({
    queryKey: ['/api/documents', documentId, 'conversations'],
    enabled: !!documentId,
  });

  const askQuestionMutation = useMutation({
    mutationFn: async (question: string) => {
      const response = await apiRequest('POST', `/api/documents/${documentId}/questions`, { question });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/documents', documentId, 'conversations'] });
      setQuestion('');
      toast({
        title: "Question answered!",
        description: "Your question has been processed successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to process question",
        variant: "destructive",
      });
    }
  });

  const humanizeMutation = useMutation({
    mutationFn: async (text: string) => {
      const response = await apiRequest('POST', '/api/humanize', { text });
      return response.json();
    },
    onSuccess: (data) => {
      setHumanizedText(data.humanizedText);
      toast({
        title: "Text humanized!",
        description: "Your text has been successfully humanized.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to humanize text",
        variant: "destructive",
      });
    }
  });

  const handleAskQuestion = () => {
    if (!question.trim()) return;
    askQuestionMutation.mutate(question);
  };

  const handleHumanizeText = () => {
    if (!textToHumanize.trim()) return;
    humanizeMutation.mutate(textToHumanize);
  };

  const downloadContent = async (type: 'summary' | 'conversation' | 'humanized', content?: string) => {
    try {
      if (type === 'humanized' && content) {
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'humanized_text.txt';
        a.click();
        URL.revokeObjectURL(url);
      } else {
        const response = await fetch(`/api/download/${type}/${documentId}`);
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = response.headers.get('content-disposition')?.split('filename=')[1]?.replace(/"/g, '') || 'download.txt';
        a.click();
        URL.revokeObjectURL(url);
      }
      
      toast({
        title: "Download started!",
        description: "Your file is being downloaded.",
      });
    } catch (error) {
      toast({
        title: "Download failed",
        description: "Could not download the file.",
        variant: "destructive",
      });
    }
  };

  if (!document) return null;

  return (
    <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
      <CardContent className="p-0">
        <Tabs defaultValue="summary" className="w-full">
          <div className="border-b border-border/50 px-6 py-4">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="summary" className="flex items-center gap-2">
                <List className="w-4 h-4" />
                Summary
              </TabsTrigger>
              <TabsTrigger value="qa" className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4" />
                Q&A
              </TabsTrigger>
              <TabsTrigger value="humanize" className="flex items-center gap-2">
                <UserPen className="w-4 h-4" />
                Humanize
              </TabsTrigger>
              <TabsTrigger value="preview" className="flex items-center gap-2">
                <Eye className="w-4 h-4" />
                Preview
              </TabsTrigger>
            </TabsList>
          </div>

          <div className="p-6">
            <TabsContent value="summary" className="mt-0">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold text-foreground flex items-center gap-2">
                  <Sparkles className="w-6 h-6 text-yellow-500" />
                  Smart Summary Ready!
                </h3>
                <Button
                  onClick={() => downloadContent('summary')}
                  className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 shadow-lg hover:shadow-xl transition-all"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              </div>

              <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-xl p-6 border border-blue-200 dark:border-blue-800">
                <div className="prose prose-lg max-w-none dark:prose-invert">
                  <h4 className="text-xl font-semibold text-foreground mb-4">Document Summary</h4>
                  <div className="text-muted-foreground whitespace-pre-wrap">
                    {document.summary || "Generating summary..."}
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="qa" className="mt-0">
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-foreground mb-4 flex items-center gap-2">
                  <MessageCircle className="w-6 h-6 text-yellow-500" />
                  Ask anything from this document!
                </h3>

                <div className="flex gap-4">
                  <div className="flex-1">
                    <Input
                      placeholder="Type your question here..."
                      value={question}
                      onChange={(e) => setQuestion(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleAskQuestion()}
                      className="h-12"
                    />
                  </div>
                  <Button
                    onClick={handleAskQuestion}
                    disabled={askQuestionMutation.isPending || !question.trim()}
                    className="bg-gradient-to-r from-primary to-secondary hover:from-secondary hover:to-primary shadow-lg hover:shadow-xl transition-all h-12"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Ask
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                {conversations.map((conv) => (
                  <div
                    key={conv.id}
                    className="bg-muted/50 rounded-xl p-4 border border-border/50"
                  >
                    <div className="mb-3">
                      <div className="flex items-center gap-2 mb-2">
                        <User className="w-5 h-5 text-primary" />
                        <span className="font-semibold text-foreground">You asked:</span>
                      </div>
                      <p className="text-foreground ml-7">{conv.question}</p>
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Bot className="w-5 h-5 text-secondary" />
                          <span className="font-semibold text-foreground">AI Assistant:</span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => downloadContent('conversation')}
                          className="text-green-600 hover:text-green-700"
                        >
                          <Download className="w-3 h-3 mr-1" />
                          Download
                        </Button>
                      </div>
                      <div className="ml-7 p-4 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 rounded-lg border border-purple-200 dark:border-purple-800">
                        <p className="text-foreground whitespace-pre-wrap">{conv.answer}</p>
                        <div className="mt-2 text-sm text-muted-foreground flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          Referenced from document content
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="humanize" className="mt-0">
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-foreground mb-4 flex items-center gap-2">
                  <UserPen className="w-6 h-6 text-yellow-500" />
                  Humanize Your Text
                </h3>
                <p className="text-muted-foreground mb-4">
                  Select text from your document or paste it here to make it more human-like and engaging.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">
                    Original Text
                  </label>
                  <Textarea
                    placeholder="Paste the text you want to humanize..."
                    value={textToHumanize}
                    onChange={(e) => setTextToHumanize(e.target.value)}
                    className="h-48 resize-none"
                  />
                  <Button
                    onClick={handleHumanizeText}
                    disabled={humanizeMutation.isPending || !textToHumanize.trim()}
                    className="mt-4 w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 shadow-lg hover:shadow-xl transition-all"
                  >
                    <Sparkles className="w-4 h-4 mr-2" />
                    Humanize Text
                  </Button>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">
                    Humanized Result
                  </label>
                  <div className="h-48 p-4 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 border border-green-200 dark:border-green-800 rounded-lg overflow-y-auto">
                    <p className="text-foreground whitespace-pre-wrap">
                      {humanizedText || "Your humanized text will appear here once processing is complete."}
                    </p>
                  </div>
                  <Button
                    onClick={() => downloadContent('humanized', humanizedText)}
                    disabled={!humanizedText}
                    className="mt-4 w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 shadow-lg hover:shadow-xl transition-all"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download Result
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="preview" className="mt-0">
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-foreground flex items-center gap-2">
                  <Eye className="w-6 h-6 text-yellow-500" />
                  Original Document Preview
                </h3>
              </div>

              <div className="bg-background rounded-xl border border-border/50 p-6 max-h-96 overflow-y-auto">
                <div className="prose max-w-none dark:prose-invert">
                  <h4 className="text-xl font-bold text-foreground mb-4">{document.originalName}</h4>
                  <div className="text-muted-foreground whitespace-pre-wrap">
                    {document.content}
                  </div>
                </div>
              </div>
            </TabsContent>
          </div>
        </Tabs>
      </CardContent>
    </Card>
  );
}
