import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { FileUpload } from '@/components/file-upload';
import { ProcessingPanel } from '@/components/processing-panel';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useTheme } from '@/components/theme-provider';
import { Brain, Sun, Moon, History, Trash2, FileText, ArrowRight, Download } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function Home() {
  const [selectedDocumentId, setSelectedDocumentId] = useState<number | null>(null);
  const { theme, toggleTheme } = useTheme();

  const { data: documents = [] } = useQuery({
    queryKey: ['/api/documents'],
  });

  const clearHistory = () => {
    if (confirm('Are you sure you want to clear all history?')) {
      // TODO: Implement clear history
      localStorage.removeItem('document-history');
    }
  };

  const downloadProject = async () => {
    try {
      const response = await fetch('/api/download-project');
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'ai-document-genius.tar.gz';
      a.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error downloading project:', error);
    }
  };

  const formatDate = (date: string | Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20 transition-colors duration-300">
      {/* Header */}
      <header className="bg-background/80 backdrop-blur-sm border-b border-border/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-primary to-secondary p-2 rounded-xl shadow-lg">
                <Brain className="text-white w-6 h-6" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                AI Document Genius
              </h1>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={downloadProject}
                className="p-2 rounded-lg hover:bg-muted transition-colors"
                title="Download Project Files"
              >
                <Download className="w-5 h-5 text-green-600" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleTheme}
                className="p-2 rounded-lg hover:bg-muted transition-colors"
              >
                {theme === 'light' ? (
                  <Moon className="w-5 h-5 text-blue-600" />
                ) : (
                  <Sun className="w-5 h-5 text-yellow-500" />
                )}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Upload Section */}
        <section className="mb-8">
          <FileUpload onFileUploaded={setSelectedDocumentId} />
        </section>

        {/* Processing Section */}
        {selectedDocumentId && (
          <section className="mb-8">
            <ProcessingPanel documentId={selectedDocumentId} />
          </section>
        )}

        {/* History Section */}
        <section className="mb-8">
          <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold text-foreground flex items-center gap-2">
                  <History className="w-6 h-6 text-yellow-500" />
                  Recent Documents
                </h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearHistory}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="w-4 h-4 mr-1" />
                  Clear History
                </Button>
              </div>

              <div className="space-y-4">
                {documents.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No documents uploaded yet.</p>
                  </div>
                ) : (
                  documents.map((doc) => (
                    <div
                      key={doc.id}
                      className={cn(
                        "flex items-center justify-between p-4 rounded-xl border border-border/50 hover:shadow-md transition-all cursor-pointer",
                        selectedDocumentId === doc.id 
                          ? "bg-primary/10 border-primary/30" 
                          : "bg-muted/30 hover:bg-muted/50"
                      )}
                      onClick={() => setSelectedDocumentId(doc.id)}
                    >
                      <div className="flex items-center space-x-4">
                        <div className="bg-gradient-to-r from-primary to-secondary p-3 rounded-lg">
                          <FileText className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <h4 className="font-semibold text-foreground">{doc.originalName}</h4>
                          <p className="text-sm text-muted-foreground">
                            Uploaded {formatDate(doc.createdAt!)}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="bg-gradient-to-r from-green-500 to-emerald-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                          Processed
                        </span>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-muted-foreground hover:text-foreground"
                        >
                          <ArrowRight className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </section>
      </main>
    </div>
  );
}
